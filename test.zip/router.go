package main

import (
    "OpenStorage/cmd"
    "github.com/gorilla/mux"
)

func SetupRouter() *mux.Router {
    r := mux.NewRouter()
    r.HandleFunc("/run/{cmd}/{subcmd}", cmd.Dispatch).Methods("GET")
    return r
}
