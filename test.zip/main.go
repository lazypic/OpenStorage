package main

import (
    "log"
    "net/http"
)

func main() {
    router := SetupRouter()
    log.Println("ZFS Monitor API listening on :8080")
    log.Fatal(http.ListenAndServe(":8080", router))
}